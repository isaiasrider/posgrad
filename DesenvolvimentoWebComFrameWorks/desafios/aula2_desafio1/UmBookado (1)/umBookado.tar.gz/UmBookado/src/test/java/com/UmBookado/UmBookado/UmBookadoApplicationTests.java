package com.UmBookado.UmBookado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmBookadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
