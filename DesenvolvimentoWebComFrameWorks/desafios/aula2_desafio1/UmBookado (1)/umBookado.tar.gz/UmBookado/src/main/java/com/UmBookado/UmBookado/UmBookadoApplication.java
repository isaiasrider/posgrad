package com.UmBookado.UmBookado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmBookadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UmBookadoApplication.class, args);
	}

}
