package com.UmBookado.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Livros extends JpaRepository <com.UmBookado.UmBookado.Entity.Livros, String> {
}
